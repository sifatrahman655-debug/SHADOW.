# SHADOW — Android Private Vault starter

A dark Android app starter with:
- First gate: six-digit PIN
- Second gate: user-defined question and answer
- Android Photo Picker import
- AES-256-GCM encryption using an Android Keystore key
- App-private file storage (not in the public gallery)
- Screenshot / recent-app preview blocking
- Android backup disabled

## Important limitations in this starter
- Google Drive backup is not connected yet. It requires a Google Cloud project, OAuth consent configuration, and a tested restore flow.
- The current vault screen lists encrypted file records and supports deletion; image preview, export, credential changes, failed-attempt throttling, biometric unlock, and backup/restore are future work.
- This is source code, not a prebuilt APK. Build it with Android Studio (JDK 17 and Android SDK 35).
- If the app is uninstalled, app-private files are normally removed. If the Android Keystore key is also removed, encrypted local files cannot be decrypted. A Drive backup, once implemented, would remain separately in the Google account.
- The PIN and answer hashing in this prototype is a starter implementation, not a production-grade credential system. Before storing highly sensitive content, replace it with a salted, slow password KDF (such as PBKDF2/Argon2 where supported), add lockout/rate limiting, and complete a security review.
