package com.shadow.vault

import android.content.Context
import android.os.Bundle
import android.net.Uri
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

private val Bg = Color(0xFF090A0D)
private val Panel = Color(0xFF17191F)
private val Accent = Color(0xFFB6A0FF)
private val TextMain = Color(0xFFF4F2FA)
private val Muted = Color(0xFF9A98A5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(8192, 8192) // FLAG_SECURE: blocks screenshots/recents previews
        setContent { ShadowApp(this) }
    }
}

@Composable
private fun ShadowApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("shadow_setup", Context.MODE_PRIVATE) }
    var setupDone by remember { mutableStateOf(prefs.getBoolean("ready", false)) }
    var stage by remember { mutableStateOf(if (setupDone) 0 else -1) }
    var pin by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var photos by remember { mutableStateOf(VaultStore.list(context)) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        var saved = 0
        uris.forEach { if (VaultStore.import(context, it)) saved++ }
        photos = VaultStore.list(context)
        message = if (saved > 0) "$saved photo(s) encrypted and saved." else "No photos were added."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = TextMain, onSurface = TextMain
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (stage) {
                -1 -> SetupScreen(
                    pin, { pin = it.filter(Char::isDigit).take(6) },
                    question, { question = it },
                    answer, { answer = it },
                    onCreate = {
                        if (pin.length != 6 || question.isBlank() || answer.isBlank()) {
                            message = "Set a 6-digit PIN, a question and its answer."
                        } else {
                            prefs.edit()
                                .putString("pin_hash", hash(pin))
                                .putString("question", question.trim())
                                .putString("answer_hash", hash(answer.trim()))
                                .putBoolean("ready", true).apply()
                            setupDone = true; stage = 0; pin = ""; answer = ""
                        }
                    }, message
                )
                0 -> LoginScreen(
                    pin, { pin = it.filter(Char::isDigit).take(6) },
                    onContinue = {
                        if (hash(pin) == prefs.getString("pin_hash", "")) {
                            stage = 1; pin = ""; message = ""
                        } else { message = "Incorrect PIN." ; pin = "" }
                    }, message
                )
                1 -> AnswerScreen(
                    prefs.getString("question", "Say anything") ?: "Say anything",
                    answer, { answer = it },
                    onUnlock = {
                        if (hash(answer.trim()) == prefs.getString("answer_hash", "")) {
                            stage = 2; answer = ""; message = ""
                        } else { message = "That answer doesn't match."; answer = "" }
                    }, message
                )
                else -> VaultScreen(
                    photos, message,
                    onAdd = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    onDelete = { name -> VaultStore.delete(context, name); photos = VaultStore.list(context) },
                    onLock = { stage = 0; message = "" }
                )
            }
        }
    }
}

@Composable
private fun Header(subtitle: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("SHADOW", fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp, color = TextMain)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = Muted, fontSize = 13.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun SetupScreen(
    pin: String, setPin: (String) -> Unit, question: String, setQuestion: (String) -> Unit,
    answer: String, setAnswer: (String) -> Unit, onCreate: () -> Unit, message: String
) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Header("CREATE YOUR PRIVATE VAULT")
        Spacer(Modifier.height(32.dp))
        Text("Create a 6-digit PIN", color = TextMain)
        SecretField(pin, setPin, "6-digit PIN", true)
        Spacer(Modifier.height(14.dp))
        Text("Your personal security question", color = TextMain)
        OutlinedTextField(question, setQuestion, Modifier.fillMaxWidth(), placeholder = { Text("e.g. What is your favourite word?") })
        Spacer(Modifier.height(14.dp))
        Text("Your secret answer", color = TextMain)
        SecretField(answer, setAnswer, "Secret answer", false)
        Spacer(Modifier.height(20.dp))
        PrimaryButton("CREATE VAULT", onCreate)
        Notice(message)
    }
}

@Composable
private fun LoginScreen(pin: String, setPin: (String) -> Unit, onContinue: () -> Unit, message: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Header("SECURITY LEVEL 01")
        Spacer(Modifier.height(38.dp))
        Text("Enter your PIN", color = TextMain, fontSize = 19.sp)
        Spacer(Modifier.height(12.dp))
        SecretField(pin, setPin, "••••••", true)
        Spacer(Modifier.height(20.dp))
        PrimaryButton("CONTINUE", onContinue)
        Notice(message)
    }
}

@Composable
private fun AnswerScreen(question: String, answer: String, setAnswer: (String) -> Unit, onUnlock: () -> Unit, message: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Header("SECURITY LEVEL 02")
        Spacer(Modifier.height(36.dp))
        Text("Say anything", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
        Text(question, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(14.dp))
        SecretField(answer, setAnswer, "Your secret answer", false)
        Spacer(Modifier.height(20.dp))
        PrimaryButton("UNLOCK VAULT", onUnlock)
        Notice(message)
    }
}

@Composable
private fun VaultScreen(
    photos: List<String>, message: String, onAdd: () -> Unit,
    onDelete: (String) -> Unit, onLock: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("SHADOW", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                Text("YOUR PRIVATE SPACE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            }
            TextButton(onClick = onLock) { Text("LOCK", color = Accent) }
        }
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Private photos (${photos.size})", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)) { Text("+ ADD") }
        }
        Spacer(Modifier.height(14.dp))
        if (photos.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("＋", color = Accent, fontSize = 42.sp)
                    Text("Your vault is empty", color = TextMain)
                    Text("Add photos to store them encrypted.", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(photos) { name ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(name, color = TextMain, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onDelete(name) }) { Text("DELETE", color = Color(0xFFFF8A8A)) }
                    }
                }
            }
        }
        Notice(message)
        Text("Files are stored encrypted in this app's private storage.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SecretField(value: String, onValue: (String) -> Unit, hint: String, numeric: Boolean) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(hint) }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.NumberPassword else KeyboardType.Password)
    )
}
@Composable
private fun PrimaryButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(52.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
        shape = RoundedCornerShape(14.dp)) { Text(label, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
}
@Composable
private fun Notice(message: String) {
    if (message.isNotBlank()) { Spacer(Modifier.height(12.dp)); Text(message, color = Accent, fontSize = 12.sp) }
}

private fun hash(value: String): String =
    Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(value.toByteArray()), Base64.NO_WRAP)

private object VaultStore {
    private const val KEY_ALIAS = "shadow_photo_key"
    private fun dir(context: Context) = File(context.filesDir, "vault").apply { mkdirs() }

    private fun key(): SecretKey {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    fun import(context: Context, uri: Uri): Boolean = try {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.iv + cipher.doFinal(bytes)
        val name = "photo_${System.currentTimeMillis()}_${SecureRandom().nextInt(100000)}.sv"
        File(dir(context), name).writeBytes(encrypted)
        true
    } catch (_: Exception) { false }

    fun list(context: Context): List<String> = dir(context).listFiles()?.map { it.name }?.sortedDescending() ?: emptyList()
    fun delete(context: Context, name: String) { File(dir(context), name).delete() }
}
